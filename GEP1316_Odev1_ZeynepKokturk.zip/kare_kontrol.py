"""PNG kare dizilerindeki eksikleri bulan komut satırı uygulaması."""

import re
from pathlib import Path


def tam_sayi_oku(mesaj, en_az, en_cok):
    while True:
        try:
            sayi = int(input(mesaj))
        except ValueError:
            print("Uyarı: Bir tam sayı girin.")
            continue

        if en_az <= sayi <= en_cok:
            return sayi
        print(f"Uyarı: {en_az} ile {en_cok} arasında bir sayı girin.")


def sahne_oku():
    while True:
        sahne = input("Sahne kodu (ör. SC01): ").strip()
        if re.fullmatch(r"[A-Za-z0-9-]{1,24}", sahne):
            return sahne
        print("Uyarı: 1–24 karakter kullanın. Harf, rakam ve tire geçerlidir.")


def kareleri_kontrol_et(klasor, sahne, baslangic, bitis):
    desen = re.compile(rf"{re.escape(sahne)}_([0-9]{{4}})\.png", re.IGNORECASE)
    bulunan = set()

    for dosya in klasor.iterdir():
        eslesme = desen.fullmatch(dosya.name)
        if eslesme and dosya.is_file():
            bulunan.add(int(eslesme.group(1)))

    beklenen = range(baslangic, bitis + 1)
    eksik = [kare for kare in beklenen if kare not in bulunan]
    return len(beklenen) - len(eksik), eksik


def rapor_hazirla(sahne, baslangic, bitis, bulunan, eksik):
    if not eksik:
        durum = "Tüm kareler mevcut."
    elif bulunan == 0:
        durum = "Beklenen karelerin hiçbiri bulunamadı."
    else:
        durum = "Eksik kareler var."

    eksik_liste = ", ".join(f"{kare:04d}" for kare in eksik) or "Yok"
    return (
        f"=== KARE KONTROL RAPORU | {sahne} ===\n"
        f"Beklenen aralık : {baslangic:04d}–{bitis:04d}\n"
        f"Bulunan kare    : {bulunan}/{bitis - baslangic + 1}\n"
        f"Eksik kare      : {len(eksik)}\n"
        f"Eksik numaralar : {eksik_liste}\n"
        f"Durum           : {durum}\n"
    )


def sahneyi_kontrol_et():
    sahne = sahne_oku()
    baslangic = tam_sayi_oku("İlk beklenen kare: ", 0, 9999)
    bitis = tam_sayi_oku("Son beklenen kare: ", baslangic, 9999)
    klasor_girdisi = input("PNG klasörünün yolu: ").strip()
    if not klasor_girdisi:
        print("Uyarı: Klasör yolu boş bırakılamaz. Menüye dönülüyor.")
        return

    try:
        klasor = Path(klasor_girdisi).expanduser()
        bulunan, eksik = kareleri_kontrol_et(klasor, sahne, baslangic, bitis)
    except (OSError, ValueError, RuntimeError):
        print("Uyarı: Klasör okunamadı. Yolu kontrol edip yeniden deneyin.")
        return

    rapor = rapor_hazirla(sahne, baslangic, bitis, bulunan, eksik)
    print()
    print(rapor, end="")
    rapor_dosyasi = Path(f"rapor_{sahne}_{baslangic:04d}-{bitis:04d}.txt")
    try:
        rapor_dosyasi.write_text(rapor, encoding="utf-8")
    except OSError:
        print("Uyarı: Rapor dosyaya yazılamadı.")
    else:
        print(f"Kaydedildi: {rapor_dosyasi}")


def ana_menu():
    while True:
        print("\n1. Sahneyi kontrol et\n0. Çıkış")
        secim = input("Seçim: ").strip()
        if secim == "1":
            sahneyi_kontrol_et()
        elif secim == "0":
            print("Program kapatıldı.")
            break
        else:
            print("Uyarı: 1 veya 0 girin.")


if __name__ == "__main__":
    try:
        ana_menu()
    except (EOFError, KeyboardInterrupt):
        print("\nProgram kapatıldı.")
