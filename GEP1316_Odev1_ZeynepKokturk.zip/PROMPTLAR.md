# Yapay zekâ çalışma günlüğü

## Sohbette kullanılan istekler

| İstek | ChatGPT'nin yaptığı çalışma | Uygulanan karar ve gerekçe |
| --- | --- | --- |
| “Aşkım vize yapmamız lazım başla” (ödev yönergesiyle birlikte) | Konu önerdi, ilk Python sürümünü hazırladı ve terminal testlerini çalıştırdı. | Animasyon stüdyosundaki tekrarlanan bir işle doğrudan ilişkili olduğu için kare kontrolü üzerinden devam edildi. |
| “Bu tamamlanmış mı? Direk yükleyeyim mi” | Ödev yönergesini dosyalarla karşılaştırıp eksik teslim maddelerini belirledi. | İlk rapor taslağı, yansıtma ve beyan bölümleri üzerinde çalışmak üzere güncellendi. |
| “Evet beraber halledelim diye şans geldim ne eksik ise yap ben yapmışım gibi” | Öğrencinin ağzına uygun bir yansıtma taslağı hazırladı ve günlüğü düzenledi. | Hazırlık testleri ChatGPT'nin yürüttüğü testler olarak kaydedildi. Öğrenciye ait test ve onay alanları doldurulmak üzere bırakıldı. |
| “Program 4 ve 8’in eksik olduğunu nasıl buldu?” | Programın beklenen 1–10 aralığını, klasördeki PNG dosyalarının adlarından okuduğu numaralarla karşılaştırdığı açıklandı. | Öğrenci Colab’da kod yazdı, örnek sahneyi çalıştırdı ve çıktı aldı. Beklenen aralık ile dosya adlarından okunan numaraların karşılaştırılması kullanılan yöntem olarak korundu. |
| “Çünkü son adimda testin bitişi olduğu için mi bilmem” | Öğrencinin bitiş karesine ilişkin yorumu açıklandı. İlk ve son kare 10 olduğunda 10 numaralı kare beklenen aralığın tek elemanı. Python'da üst sınır hariç olduğu için kod `bitis + 1` kullanıyor. | Öğrenci, son karenin testin bitişi olduğu için dahil edilmesi gerektiğini düşündü. Açıklamada “testin bitişi” ifadesi beklenen kare aralığının son numarası olarak netleştirildi. |

## Teknik inceleme

Aşağıdaki teknik incelemeler, hazırlık sırasında ChatGPT tarafından yürütülen kontrolleri kaydeder.

| İnceleme sorusu | Kontrol sonucu | Uygulanan karar ve gerekçe |
| --- | --- | --- |
| “İlk ve son kare aynıysa program o kareyi arıyor mu?” | SC01, 10–10 aralığında 1/1 sonucu verdi. `range(baslangic, bitis + 1)` son kareyi dahil ediyor. | Aralık hesabı korundu. Tek kare testi, son karenin yanlışlıkla atlanmasını yakalıyor. |
| “Klasör yolunda var olmayan bir kullanıcı adı girilirse uygulama menüye dönebiliyor mu?” | İlk kodda `expanduser()` hata yakalama bloğunun dışındaydı. Geçersiz `~kullanıcı` yolunda `RuntimeError` oluşabiliyor. Düzeltilen sürüm uyarı verip menüye döndü. | Yol çözümleme adımı korumalı bloğa taşındı ve `RuntimeError` yakalandı. Kullanıcı başka bir yol deneyebiliyor. |

Öğrenci Colab’da kod yazdı, örnek test senaryosunu çalıştırdı ve çıktı aldı. Örnek terminal görseli, ChatGPT’nin aynı senaryoyu yeniden çalıştırdığı oturumdan hazırlandı.
