# Animasyon Kare Kontrolü

2D animasyon ekibi için hazırlanmış bir Python 3 komut satırı aracı. Bir çıktı klasöründeki PNG kare adlarını beklenen numara aralığıyla karşılaştırır, eksikleri ekrana yazar ve aynı raporu TXT olarak kaydeder. Program karelerin varlığını dosya adına göre denetler.

## Çalıştırma

Terminalde bu klasörü açıp `python3 kare_kontrol.py` çalıştırın. Windows'ta `py kare_kontrol.py` komutunu da kullanabilirsiniz. Ek Python paketi gerekmez.

1. Menüden `1` seçin.
2. Örnek için sahne kodunu `SC01`, ilk kareyi `1`, son kareyi `10`, klasörü `ornek_kareler` girin.
3. Sonuçta `0004` ve `0008` görünür ve terminalin çalışma klasöründe `rapor_SC01_0001-0010.txt` oluşur.
4. Menüye dönünce `0` ile çıkın.

Dosya adı biçimi `SAHNE_0001.png` şeklindedir. Program klasörün doğrudan içindeki dosyalara bakar. Aralığın iki ucu dahildir ve numaralar 0–9999 arasındadır. Sahne adı ve uzantı büyük/küçük harfe duyarsızdır. Aynı sahne ve aralık yeniden kontrol edilirse TXT güncellenir.

## Örnek terminal çıktısı

![SC01 için gerçek terminal oturumu](terminal-ciktisi.png)

## Testler

| Girdi | Beklenen | Gerçek |
| --- | --- | --- |
| SC01, 1–10, örnek klasör | 8/10, 0004 ve 0008 eksik, TXT oluşur | 8/10, 0004 ve 0008 eksik, TXT içeriği ekranla aynı |
| SC01, 10–10, örnek klasör | 1/1, aralığın iki ucu da dahil | 1/1, tüm kareler mevcut |
| SC01, 1–2, boş klasör | 0/2, 0001 ve 0002 eksik | 0/2, 0001 ve 0002 eksik |
| Menüde 9, sahnede ../x, ilk karede abc, son karede ilk kareden küçük sayı | Uyarı ve yeniden giriş | Dört uyarı, düzeltilen girdilerle 1/1 |
| Olmayan klasör | Uyarı, menüye dönüş | Klasör uyarısı, menüden çıkış çalıştı |
| SC02, 1–2, yalnız SC01 içeren örnek klasör | 0/2 | 0/2, 0001 ve 0002 eksik |

Test tablosundaki çalıştırmalar ilk taslak hazırlanırken ChatGPT ile yapıldı. Zeynep Köktürk ayrıca Colab’da kod yazdı ve örnek sahneyi çalıştırarak çıktı aldı. README’deki görsel, örnek testin ChatGPT tarafından yeniden çalıştırılan terminal oturumundan alındı.
