# Zeynep Köktürk · GEP1316 Web Portfolyosu

[GitHub Pages adresi](https://zeynkktrk-rgb.github.io/gep1316-web-portfolyo/) · Aşağıdaki depo adıyla yayın açıldıktan sonra çalışır.

Ana sayfa, Hakkımda, Projeler ve İletişim sayfalarından oluşan statik portfolyo. Ortak CSS ve JavaScript kullanır. Projeleri arayabilir, kategoriye göre süzebilir, renk temasını değiştirebilir ve iletişim taslağını doğrulayabilirsiniz.

## Yerelde açma

`index.html` dosyasını tarayıcıda açın. İsterseniz bu klasörde `python3 -m http.server 8000` çalıştırıp `http://localhost:8000` adresini ziyaret edin.

## GitHub Pages

1. Mevcut ders deposunu korumak için **gep1316-web-portfolyo** adlı yeni bir depo oluşturun.
2. ZIP’i açın ve içindeki dosyaları deponun köküne yükleyin. `index.html` ilk dosya seviyesinde olmalı.
3. **Settings → Pages → Deploy from a branch → main → /(root) → Save**.
4. Pages ekranında görünen siteyi açıp dört sayfayı kontrol edin. Farklı depo adı kullanırsanız README’nin ilk bağlantısını Pages ekranındaki URL ile değiştirin.
5. Tarih, imza ve yayın URL’sini rapora ekleyin. Ödev alanında imzalı raporu ve canlı URL’yi paylaşın.

[GitHub Pages yayın ayarları](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

## Gizlilik

Form taslağı tarayıcı içinde doğrular. Sunucuya mesaj veya kişisel iletişim bilgisi göndermez. Tema tercihi tarayıcıda saklanabilir. Takip betiği ve harici font isteği kullanılmaz.
