const root = document.documentElement;
const themeButton = document.querySelector("#theme");

function setTheme(dark) {
  root.dataset.theme = dark ? "dark" : "light";
  themeButton.setAttribute("aria-pressed", String(dark));
}

let darkTheme = false;
try {
  darkTheme = localStorage.getItem("portfolio-theme") === "dark";
} catch {
  // Theme stays usable when storage is unavailable.
}
setTheme(darkTheme);
themeButton.hidden = false;
themeButton.addEventListener("click", () => {
  const dark = root.dataset.theme !== "dark";
  setTheme(dark);
  try {
    localStorage.setItem("portfolio-theme", root.dataset.theme);
  } catch {
    // The updated theme still applies to the current page.
  }
});

const mobile = matchMedia("(max-width: 640px)");
const menuButton = document.querySelector(".menu-button");
const navigation = document.querySelector("#site-nav");

function setMenu(open) {
  navigation.hidden = mobile.matches && !open;
  menuButton.setAttribute("aria-expanded", String(open));
}

function updateMenu() {
  const focusInNavigation = navigation.contains(document.activeElement);
  menuButton.hidden = !mobile.matches;
  if (mobile.matches && focusInNavigation) menuButton.focus();
  setMenu(false);
}

updateMenu();
mobile.addEventListener("change", updateMenu);
menuButton.addEventListener("click", () => {
  setMenu(menuButton.getAttribute("aria-expanded") === "false");
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && menuButton.getAttribute("aria-expanded") === "true") {
    setMenu(false);
    menuButton.focus();
  }
});

const filters = document.querySelector("#filters");
if (filters) {
  const search = document.querySelector("#search");
  const category = document.querySelector("#category");
  const cards = document.querySelectorAll(".card");
  const results = document.querySelector("#results");

  function filterProjects() {
    const query = search.value.trim().toLocaleLowerCase("tr");
    let visible = 0;
    for (const card of cards) {
      const matchesText = card.textContent.toLocaleLowerCase("tr").includes(query);
      const matchesCategory = !category.value || card.dataset.category === category.value;
      card.hidden = !(matchesText && matchesCategory);
      if (!card.hidden) visible += 1;
    }
    results.textContent = visible === 0 ? "Eşleşen proje bulunamadı." : `${visible} proje gösteriliyor.`;
  }

  const publishedLink = document.querySelector("[data-published-file]");
  if (location.hostname === "zeynkktrk-rgb.github.io") {
    const repository = location.pathname.split("/")[1];
    if (repository) {
      publishedLink.href = `https://github.com/zeynkktrk-rgb/${encodeURIComponent(repository)}/blob/main/${publishedLink.dataset.publishedFile}`;
    }
  }
  filters.hidden = false;
  search.addEventListener("input", filterProjects);
  category.addEventListener("change", filterProjects);
  filterProjects();
}

const contact = document.querySelector("#contact");
if (contact) {
  const status = document.querySelector("#form-status");
  const fields = [
    { input: document.querySelector("#subject"), label: "Konu", min: 3, max: 80 },
    { input: document.querySelector("#message"), label: "Mesaj", min: 10, max: 1000 },
  ];
  contact.noValidate = true;
  contact.addEventListener("submit", (event) => {
    event.preventDefault();
    let firstInvalid;
    for (const { input, label, min, max } of fields) {
      const length = input.value.trim().length;
      const error = document.querySelector(`#${input.id}-error`);
      const invalid = length < min || length > max;
      input.setAttribute("aria-invalid", String(invalid));
      error.textContent = invalid ? `${label} ${min}–${max} karakter olmalı.` : "";
      if (invalid && !firstInvalid) firstInvalid = input;
    }
    status.textContent = firstInvalid
      ? "İşaretli alanları düzelt."
      : "Taslak geçerli. Mesaj gönderilmedi.";
    if (firstInvalid) firstInvalid.focus();
  });
}
