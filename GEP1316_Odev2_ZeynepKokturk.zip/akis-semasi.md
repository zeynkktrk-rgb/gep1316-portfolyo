# Ödev 1 · Eksik kare algoritması

Bir animasyon sahnesinin beklenen ilk ve son karesi ile klasörde bulunan kare numaraları girdidir. Çıktı eksik kare numaralarının listesidir.

```mermaid
flowchart TD
    A([Başla]) --> B["Beklenen aralık ve mevcut numaraları al"]
    B --> C{"Sırada beklenen kare var mı?"}
    C -->|Evet| D{"Kare klasörde mevcut mu?"}
    D -->|Evet| C
    D -->|Hayır| E["Kareyi eksik listesine ekle"]
    E --> C
    C -->|Hayır| F["Eksik listeyi göster"]
    F --> G([Bitir])
```

Örnek mevcut kareler 1, 2, 3, 5, 6, 7, 9 ve 10. Beklenen aralık 1–10 olduğunda sonuç 4 ve 8.
