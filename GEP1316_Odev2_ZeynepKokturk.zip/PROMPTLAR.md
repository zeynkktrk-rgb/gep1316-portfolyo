# Yapay zekâ çalışma günlüğü

İlk satır öğrencinin isteğini özetler. Diğer satırlar ChatGPT’nin geliştirme sırasında kullandığı görev istemlerini ve uyguladığı kararları kaydeder.

| İstem | Karar ve gerekçe |
|---|---|
| Yönergedeki web portfolyosu, test ve rapor dosyalarını hazırla. GitHub ve Teams yüklemesini öğrenciye bırak. | Kabul. Statik site ve üç sayfalık PDF hazırlandı. Beyan gerçek iş bölümünü açıklıyor. |
| Dört HTML sayfasını bir CSS ve bir JavaScript dosyasıyla bağla. | Kabul. Gezinti ve görsel dil tutarlı kaldı, her sayfanın doğrudan bağlantısı var. |
| Önceki ders çalışmalarından dört proje kartı oluştur. | Düzenlendi. Mevcut depo kaynakları kullanıldı, akış şeması özeti ayrı kaynak olarak pakete eklendi. |
| Projeleri arama ve kategoriye göre filtrele. | Kabul. Arama Türkçe küçük harf dönüşümüyle çalışıyor. Kategori ile metin koşulu birlikte uygulanıyor. |
| İletişim için alan doğrulaması ve geri bildirim yaz. | Düzenlendi. Gönderim hizmeti yerine tarayıcı içi taslak doğrulaması kullanıldı. Gizlilik açıklaması eklendi. |
| Dar ekranda menü, klavye odağı, form ve temayı kontrol et. | Düzenlendi. Ekran daralırken kapanan menüde kalan odak, görünür menü düğmesine taşındı. |
| Gerçek tarayıcıda üç ekran boyutunu ve geçerli/geçersiz form girdilerini dene. | Kabul. Üç ekran görüntüsü ve test sonuçları rapora eklendi. |

## Erişilebilirlik düzeltmesi

İlk sürümde genişlik değiştiğinde menü kapatılıyor, fakat etkin bağlantı menünün içinde kalabiliyordu. Tarayıcı testinde odağın mobil menü düğmesine gelmediği görüldü. Mobil görünüme geçerken odak menü içindeyse odağı görünür menü düğmesine aktaran kontrol eklendi. Escape ile kapatma ve odağın dönüşü de sınandı.
